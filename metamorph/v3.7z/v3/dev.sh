#!/usr/bin/env sh
rm *_gscript.exe
# go-bindata data/*
go build main.go
gscript --debug compile --enable-logging --obfuscation-level 3 eval-enc-js.gs.js;
mv $TEMP/*_gscript.exe .