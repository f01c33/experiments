package main

import "fmt"

func main() {
	fmt.Println("do evil things")
}
