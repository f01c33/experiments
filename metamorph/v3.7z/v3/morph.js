console.log("lalala");

return "owned";