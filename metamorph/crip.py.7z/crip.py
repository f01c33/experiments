import random
import zlib
import base64
import gc
import dis
import marshal

'''
def enc(code):
    n_gerados = random.randint(len(code)//2,len(code)-1)
    sift = random.randint(0,10)
    listid = []
    end = []
    for i in range(n_gerados):
        while True:
            r = random.randint(0,len(code)-1)
            if r not in listid:
                listid.append(r)
                break
    listid.sort()
    out = [0 for i in range(len(code)+len(listid))]
    ic = 0
    m = max(code)
    for i in range(len(out)):
        if i in listid:
            out[i] = random.randint(0,m)
        else:
            out[i] = code[ic]
            ic += 1
    return bytes(out+listid+[n_gerados])

def dec(code):
    code = code
    n_gerados = code[-1]
    listid = code[-n_gerados-1:-1]
    code = code[:-n_gerados-1]
    for i in listid: code[i] = None
    return bytes([i for i in code if i is not None])
'''

enc = lambda ar: ar[::-1]
dec = lambda ar: ar[::-1]


def t():
    x = 0
    print("Exploit 1=", x+1)


f_enc = lambda f: enc(str(base64.b64encode(zlib.compress(marshal.dumps(f.__code__),9))))
f_dec = lambda f: marshal.loads(zlib.decompress(base64.b64decode(dec(f).decode())))

def poli():
    print("Poli")
    # primeiro estagio

    #zlib.decompress(base64.b64decode(codeb))
    out = ['import zlib, marshal, base64\nexec(marshal.loads(zlib.decompress(base64.b64decode(',codeb,'))))']
    with open('gen_'+chr(random.randint(60,90))+'.py', 'w') as file:
        #file.write(str(out))
        for i in out: file.write(i)

def main():
    print("Meua migo")
    exec(lambda f: marshal.loads(zlib.decompress(base64.b64decode(bin(dec(f)))))("'==Qwho3OBgBWjArFKhsLJOmFyD6rANLK5+TW1gzvY9LJvWzN0k7Pl8NW0WrK/W1N/MyPRpEpNgYoSGLWBDZCeZWUBtmFxP5VkKx+oBmoZ+5kQGlWlX8/pQQv4LLazQAMkKTMzQzMLCDpwUNMkCDlyYNMkiEDYhbgdiYBYGIGEAIz7pNe'b") )


print(f_enc(t) == eval(f_dec(t))

'''
#poli()
with open(__file__, 'r') as file:
    for line in file:
        print(line)
#print(__file__)

#main()
'''
